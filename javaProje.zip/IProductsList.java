public interface IProductsList{
    // Ürünleri tabloda gösstermeye yarayan fonksiyonu içeren interface
    void viewProductsInFrame();
}
