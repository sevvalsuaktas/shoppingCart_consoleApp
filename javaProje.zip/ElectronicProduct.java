public class ElectronicProduct extends Product {
    // Product class'ından türeyen ElectronicProduct sınıfı
    public ElectronicProduct(String id, String name, double price) {
        super(id, name, price);
    }
}
