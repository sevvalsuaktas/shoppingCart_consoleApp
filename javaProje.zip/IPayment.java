public interface IPayment {
    // Kart ekleme ve ödeme yapma fonksiyonlarını içeren interface
    void add();
    void makePayment();
}
