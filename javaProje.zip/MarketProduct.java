public class MarketProduct extends Product{
    // Product class'ından türeyen MarketProduct sınıfı
    public MarketProduct(String id,String name, double price){
        super(id,name,price);
    }
}